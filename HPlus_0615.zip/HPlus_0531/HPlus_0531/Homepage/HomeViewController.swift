//
//  HomeViewController.swift
//  HPlus_0531
//
//  Created by KAREN_JIANG on 2020/6/9.
//  Copyright © 2020 KAREN_JIANG. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var lbl_cals: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    


}
